<?php

$security_areas['SA_ACCRUALS'] = array(SS_GL|141, "Revenue / Cost Accruals");

?>
